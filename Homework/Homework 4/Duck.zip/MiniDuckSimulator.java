
public class MiniDuckSimulator {
	public static void main(String[] args) {

		Duck mallard = new MallardDuck();
		mallard.performFly();
		mallard.performQuack();
		mallard.display();

		Duck rubberDuck = new RubberDuck();
		rubberDuck.performFly();
		rubberDuck.performQuack();
		rubberDuck.display();
		
		Duck LoudmouthDuck = new LoudmouthDuck();
		LoudmouthDuck.performFly();
		LoudmouthDuck.performQuack();
		LoudmouthDuck.display();

		System.out.println("\nRubber ducky eats a magic pellet.");
		rubberDuck.setFlyBehavior(new RocketFly());
		rubberDuck.performFly();

		System.out.println("\nMallard duck eats a magic pellet.");
		mallard.setFlyBehavior(new RocketFly());
		System.out.println("Mallard says:");
		mallard.performQuack();
		
		System.out.println("\nLoud Mouth duck eats a magic pellet");
		LoudmouthDuck.setFlyBehavior(new RocketFly());
		System.out.println("Loud mouth duck says: ");
		LoudmouthDuck.performQuack();
	}
}
