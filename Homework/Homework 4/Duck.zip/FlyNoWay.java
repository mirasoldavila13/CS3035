public class FlyNoWay implements FlyBehavior{

	@Override
	public void fly() {}

}
