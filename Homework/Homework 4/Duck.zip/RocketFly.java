public class RocketFly implements FlyBehavior{

	@Override
	public void fly() {
		System.out.println("I'm blasting off!!");	
	}

}