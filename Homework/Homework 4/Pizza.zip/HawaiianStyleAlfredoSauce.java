package headfirst.factory.pizzaaf;

public class HawaiianStyleAlfredoSauce implements Sauce{
	public String toString() {
		return "Hawaiian Style Alfredo Sauce";
	}
}
