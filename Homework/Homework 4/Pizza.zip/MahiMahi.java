package headfirst.factory.pizzaaf;

public class MahiMahi implements seafoods {

	public String toString() {
		return "Mahi Mahi from the sea";
	}
	
	
	
	
	
	
	
	
}
