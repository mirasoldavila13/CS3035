package headfirst.factory.pizzaaf;

public class GoudaCheese implements Cheese{
	public String toString() {
		return "Shredded Gouda";
	}
}
