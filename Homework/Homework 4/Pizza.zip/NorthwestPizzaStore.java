package headfirst.factory.pizzaaf;

public class NorthwestPizzaStore extends PizzaStore{
	protected Pizza createPizza(String item) {
		Pizza pizza = null;
		PizzaIngredientFactory ingredientFactory = 
			new NorthwestIngredientFactory();
 
		if (item.equals("cheese")) {
  
			pizza = new CheesePizza(ingredientFactory);
			pizza.setName("North West Style Cheese Pizza");
  
		} else if (item.equals("veggie")) {
 
			pizza = new VeggiePizza(ingredientFactory);
			pizza.setName("North West Style Veggie Pizza");
 
		} else if (item.equals("MahiMahi")) {
 
			pizza = new NorthWestPizza(ingredientFactory);
			pizza.setName("North West Style Mahi Mahi Pizza");
 
		} else if (item.equals("pepperoni")) {

			pizza = new PepperoniPizza(ingredientFactory);
			pizza.setName("North West Style Pepperoni Pizza");
 
		} 

		return pizza;
	}
}
