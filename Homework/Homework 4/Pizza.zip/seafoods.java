package headfirst.factory.pizzaaf;

public interface seafoods {
	public String toString();
}
